# wplay/env/env_manager.py

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any

class EnvManager:
    """
    Entorno basado en transiciones precomputadas para entrenamiento RL offline.

    Carga un CSV de transiciones (generado por FeatureEngineerDeep → rl_input.csv)
    y ofrece una API similar a OpenAI Gym:
      - reset() → estado inicial
      - step(action) → (next_state, reward, done, info)

    Detecta automáticamente:
      - todas las columnas de estado (cualquier columna que NO sea 'action', 'reward' ni empiece con 'next_')
      - todas las columnas de siguiente estado (prefijo 'next_')
      - la columna 'reward'
    """

    def __init__(self, rl_csv_path: str):
        """
        :param rl_csv_path: Ruta al CSV de transiciones para RL.
        """
        # Cargar todas las transiciones
        self.df = pd.read_csv(rl_csv_path)

        # Detectar automáticamente las columnas de estado y next_state
        # Estado: todo lo que no sea 'action', 'reward' ni empiece con 'next_'
        self.state_cols = [
            c for c in self.df.columns
            if c not in ("action", "reward") and not c.startswith("next_")
        ]
        # next_state: cualquier columna que empiece con 'next_'
        self.next_state_cols = [
            c for c in self.df.columns
            if c.startswith("next_")
        ]
        self.reward_col = "reward"

        self._max_index = len(self.df) - 1
        self._current_index = 0

    def reset(self) -> np.ndarray:
        """
        Reinicia el entorno al primer paso.
        :return: Array 1D con el estado inicial.
        """
        self._current_index = 0
        state = self.df.loc[self._current_index, self.state_cols].values.astype(float)
        return state

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Ejecuta un paso en el entorno.
        :param action: índice de la acción elegida (no usado para reward offline).
        :return: (next_state, reward, done, info)
        """
        row = self.df.loc[self._current_index]
        # Recompensa precomputada
        reward = float(row[self.reward_col])
        # Obtener siguiente estado
        next_state = row[self.next_state_cols].values.astype(float)
        # Comprobar si llegamos al final del dataset
        done = self._current_index >= self._max_index
        info = {}  # Aquí podrías agregar métricas o debug
        # Avanzar el puntero (si no estamos en done)
        if not done:
            self._current_index += 1
        return next_state, reward, done, info

    def render(self):
        """
        (Opcional) Método para visualizar el estado actual.
        """
        cols = self.state_cols + self.next_state_cols + [self.reward_col]
        row = self.df.loc[self._current_index, cols]
        print(row.to_dict())

    @property
    def observation_space_dim(self) -> int:
        """Dimensión del vector de entrada (state)."""
        return len(self.state_cols)

    @property
    def action_space_dim(self) -> int:
        """
        Número de acciones posibles.
        Intenta inferirlo de la columna 'action' si existe, sino devuelve 0.
        """
        if 'action' in self.df.columns:
            return int(self.df['action'].max()) + 1
        return 0
