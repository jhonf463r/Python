# IABV UAAL — R10 v0.7.2 reconstructed contract (repair candidate)

**Artifact ID:** `R10_V0_7_2_RECONSTRUCTED_CONTRACT`  
**Classification:** `RECONSTRUCTED_FROM_REVIEW` + `PROPOSED`  
**Governance:** `KEEP_BLOCKED`  
**Purpose:** repair D1–D6 from the independent static audit of the v0.7.1 reconstruction.  
**Review state:** `PENDING_INDEPENDENT_DELTA_REVIEW`; no execution/test/runtime claim.

## 0. Source provenance and supersession

The literal R10 v0.6 contract and its original test matrix remain `NOT_RECOVERED`. The earlier reconstructed reference is available at `R10_V0_7_RECONSTRUCTED_CONTRACT_REFERENCE.md`, SHA-256 `5babd981b0d993c0fceec47ef8d62ebff5ce4daac4ae3561d9ebc3dd1b7912e7`. The independent v0.7.1 audit report is the accompanying file `R10_V0_7_1_AUDIT_REPORT_CLAUDE.md` and remains a report of static reasoning, not runtime evidence.

This v0.7.2 artifact is a **new reconstructed normative contract**, not the original v0.7.1 from another chat and not a byte-faithful correction of v0.6. Its test IDs T123–T196 are defined only by `R10_V0_7_2_TEST_MATRIX_T123_T196.csv`. That CSV is the sole normative test-ID registry for this package. Historical reference tests are not normative and must use the prefix `REF_V07_` whenever cited.

Provenance states: `RECOVERED` means bytes were available for inspection; `RECONSTRUCTED_FROM_REVIEW` means derived from the supplied review; `PROPOSED` means newly specified; `OWNER_REPORTED` means reported but not independently inspected; `UNPROVEN` means a technical capability has not been demonstrated. No document, test definition, or hash alone proves runtime behavior.

## 1. Normative vocabulary and identities

### 1.1 Distinct entities and IDs

Every accepted entity gets an immutable store-assigned ID. Producers provide stable event identity but do not choose `result_id`, `evaluation_id`, `contribution_id`, `effect_plan_id` or `task_seq`.

Required identities:

- `task_id`: logical objective.
- `execution_id`, `attempt_no`: one particular attempt.
- `dispatch_id`, `dispatch_nonce`, `dispatch_turn_id`: one authorized dispatch and its authenticated origin turn.
- `producer_event_id`: stable producer-side identity for a delivery.
- `turn_id`, `in_reply_to_turn_id`, `destination_session_id`: platform-attested response identity and parent relation.
- `capture_id`, `attachment_id`, `result_id`: distinct automatic capture, manual attachment, and stored result.
- `criteria_bundle_id`, `criteria_bundle_digest`, `check_set_digest`, `validation_policy_digest`, `canonicalization_version`, `eligibility_policy_version`, `selection_policy_id/digest`.
- `validation_id`, `evaluation_id`, `supersedes_evaluation_id`, `restores_event_id`.
- `strategy_lineage_id`: stable grouping for versions of a strategy.
- `result_lineage_id`: stable identity for one captured result lineage, unchanged by evaluation revisions of that same result; distinct result lineages remain distinct even when they use the same strategy or have identical bytes.
- `destination_id`, `contribution_kind`, `contribution_id`, `source_evaluation_id`, `effect_plan_id`, `tombstone_id`, `conflict_id`.
- `authorization_generation` and `projection_generation`, which are separate counters and must never be aliased.
- `task_seq`: store-assigned monotonic order comparable only within one `task_id`; there is no cross-task sequence tie-break.

An event carries `event_id`, `task_id`, affected entity IDs, `event_type`, authenticated `actor_id`, stable producer identity where required, canonical payload digest, `task_seq`, store-authenticated `accepted_at`, authorization generation, fencing token where applicable, and causal predecessor references. Producers cannot supply or rewrite store-assigned sequence/time values.

### 1.2 Metrics and projections — no ambiguous `PA` alias

The historical meaning of `PA`, and the exact literal semantics of `TS`, have not been recovered. They are not normative identifiers in this reconstructed contract. Use instead:

- `TASK_SUCCESS_COUNT`: number of logical tasks whose current adopted automatic result satisfies the frozen final-success policy, counted once per `task_id`.
- `ACTIVE_AUTO_PATTERN_CONTRIBUTION_COUNT`: number of currently visible, eligible, active automated pattern contributions; re-delivery does not add a second copy.
- `active_execution_id`: current attempt, not a success indicator.
- `current_evaluation_id_by_result`: current evaluation for one `result_lineage_id`.
- `current_task_evaluation_id`: adopted task-level evaluation pointer, which can be `null`.

These are not interchangeable. Replacing an evaluation for the same already-successful task does not increment `TASK_SUCCESS_COUNT` again. The active contribution count is a current-state projection, not a cumulative observation counter. Any historical use of `TS` or `PA` must be marked `SEMANTICS_UNRECOVERED` until its original glossary is recovered.

### 1.3 Lineages and uniqueness

`strategy_lineage_id` groups strategies and is used for analysis/routing. `result_lineage_id` scopes revisions of a single result. A strategy can have many independent result lineages. Do not use these two IDs as substitutes for one another.

For one `(destination_id, result_lineage_id, contribution_kind)`, at most one contribution may be visible/active. Successive evaluations of the same result retain the same `result_lineage_id`; their replacement contribution uses a new `contribution_id` and source evaluation. Different results from the same strategy can each contribute once under their own result lineage if separately eligible and allowed by the pattern policy. Revisions of one result cannot be double-counted.

## 2. Durable log, ordering, idempotency, and clocks

### 2.1 Task sequencer

The store atomically assigns the next `task_seq` within the `task_id` when it accepts an event. Every reducer uses the same durable event order. Sequence values local to other entities are not comparable and must never resolve a task-level winner or a semantic evaluation conflict.

The ordering of accepted events is deterministic, but arrival order alone does not settle semantic disagreement. A compare-and-set (CAS) protects pointer/version writes; it does not make two incompatible evaluations equivalent and does not authorize “highest sequence wins.”

### 2.2 Producer idempotency

For automated producer events, the uniqueness scope is `(execution_id, lane=AUTO, producer_event_id)`. For a stable identity with the same canonical digest, return `ACK_DUPLICATE` without new effects. With the same identity and a different digest, append `CONFLICT_DETECTED` with a read-visibility barrier in the same atomic acceptance operation; do not return a benign duplicate acknowledgment. An event missing `producer_event_id` is rejected at ingress as `MISSING_PRODUCER_EVENT_ID`: no `result_id`, no terminal slot, no validation, no plan, no metric change.

Digest equality is not global deduplication. Identical output digests in different tasks or executions remain separate attributed results.

### 2.3 Trusted time

The store seals `dispatched_at`, `abandon_deadline_at` and event `accepted_at`. Producer timestamps do not decide causality or abandonment. If the authoritative monotonic clock cannot be verified, operations that depend on expiry or deadlines fail closed with `CLOCK_UNAVAILABLE`.

## 3. Profiles, modes, and execution states

### 3.1 Modes and attestation

The canonical mode vocabulary is `AUTHORIZED_REAL_EXECUTION`, `DRY_RUN`, `SIMULATED`, `SANDBOX_ISOLATED`, `NO_RESULT`, and `UNKNOWN`. For an automatic result to be `BASE_ELIGIBLE`, the planned mode and independently attested observed mode must both equal `AUTHORIZED_REAL_EXECUTION`.

The dispatch record stores `planned_mode`, `execution_path_id`, attestation requirements, authorization generation and frozen criteria digest. The observed mode is attested by an independently authorized observation source. The executor or result producer cannot attest itself merely by declaring a field. A mismatch produces `MODE_MISMATCH`; missing/invalid attestation produces `MODE_UNATTESTED`; an absent or unregistered route produces `UNACCREDITED_ROUTE`.

`DRY_RUN`, `SIMULATED`, `SANDBOX_ISOLATED`, `NO_RESULT`, `UNKNOWN`, mode mismatch and unaccredited routes may be retained as isolated diagnostic records. They cannot alter automatic task success or automatic pattern projections.

### 3.2 Profiles

- `CONVERSATIONAL_CAPTURE`: needs an authenticated dispatch turn and platform-attested child response turn.
- `DIRECT_OUTPUT`: needs an output receipt from the authorized execution path with the same stable execution/dispatch identity.
- `NO_RESULT`: explicitly does not produce an automatic terminal result.

A sandbox event is not `EXECUTION_STARTED`, not a real terminal output, and not a substitute for `OUTPUT_RECEIVED` or `CAPTURE_RECEIVED`.

### 3.3 Execution state machine

Execution states: `PLANNED → DISPATCHED → EXECUTION_STARTED → RESULT_ACCEPTED`, with alternate terminal states `FAILED`, `ABORTED`, `TIMED_OUT`, `ABANDONED`, or `SUPERSEDED`. These state names are execution-only. `ABANDONED` and `SUPERSEDED` are terminal for that execution. `TASK_REOPENED` opens a new `execution_id`; it never reopens an old execution or relabels old output.

A result whose terminal event is accepted after its execution was already `SUPERSEDED` or `ABANDONED` is rejected as `LATE_STALE` with a durable rejection record; no `result_id` is minted, no terminal slot is claimed and no evaluation/effect follows. If valid terminal output was accepted before supersession, it may remain eligible as attempt evidence, but task-winner adoption still follows the current frozen policy and CAS.

## 4. Authenticated dispatch-to-response correlation

### 4.1 Mandatory platform link for AUTO

Every automatic `CONVERSATIONAL_CAPTURE` dispatch **must** possess a platform-authenticated `dispatch_turn_id` and `destination_session_id` before dispatch. These fields are not optional for automatic capture. If the target platform cannot supply them, the operation cannot use the AUTO capture profile; it must fail closed for automatic learning. A manual attachment remains separate.

The captured response must carry platform-attested (not captor-invented) `turn_id`, `in_reply_to_turn_id`, `destination_session_id` and the matching dispatch nonce/receipt. The authenticated `in_reply_to_turn_id` must equal the authenticated `dispatch_turn_id`. Enforce uniqueness `(destination_session_id, turn_id) → one execution`. Also verify dispatch receipt, captor authority, nonce, completeness, canonical digest, canonicalization version and accepted task ordering.

Nonce, session and time alone are insufficient. If the parent-turn relation is absent, unverifiable, mismatched or supplied only as an unauthenticated captor claim, record `UNCORRELATED`; do not infer correlation heuristically.

### 4.2 Terminal output slot

For AUTO, one terminal slot is keyed by `(execution_id, profile, lane=AUTO, output_ordinal=1)`. The first valid, complete and correlated terminal event accepted while the execution is eligible claims it. A different later terminal output is `EXTRA_TERMINAL_OUTPUT`; it cannot silently overwrite the first. A duplicate with same producer identity and digest is idempotent; same identity with different digest is a conflict. `MANUAL` attachments have stable `attachment_id` in a separate namespace and cannot occupy AUTO slots.

## 5. Frozen criteria and verifiable validation

Before each dispatch, the coordinator commits an immutable `criteria_bundle` with `criteria_digest`, `check_set_digest`, `validation_policy_digest`, `canonicalization_version`, `eligibility_policy_version`, profile, planned mode, execution path, abandon deadline policy and frozen selection policy/version. `DISPATCHED` must reference that bundle. Criteria cannot be frozen retroactively after dispatch.

`VALIDATION_COMPLETED` stores the **actual** `used_criteria_digest`, `used_check_set_digest`, `used_validation_policy_digest`, `used_canonicalization_version`, validator identity, validator version, execution-attestation/reference for the checks, result and per-check evidence references. `EVALUATED` must reference that validation and record the same relevant digests. All used digests/versions must equal the frozen bundle; otherwise reject the validation/evaluation with `CRITERIA_MISMATCH` and no automatic evaluation or effect.

An attested digest proves which content was named, not that the checks were actually executed. Independent evidence of validator execution remains `UNPROVEN` until demonstrated. A relaxed post-hoc criteria revision cannot make the old execution eligible. New acceptance criteria require a newly frozen bundle and a new dispatch.

## 6. Evaluation, winner selection, and conflict handling

### 6.1 Evaluation states and identities

Evaluation states are `PENDING`, `VALIDATING`, `VALID`, `INVALID`, `INDETERMINATE`, `COMPLETED_UNVERIFIED`, `QUARANTINED`, `SUPERSEDED`, `VOIDED`. Plan or execution states cannot be reused for evaluations. Each evaluation has `evaluation_id`, stable `result_lineage_id`, `criteria_bundle_digest`, all used validation digests, `evaluation_policy_digest`, canonical output digest and—when revising—`supersedes_evaluation_id`.

Same canonical evaluation identity and same content is idempotent reuse. Same identity but different canonical content is a conflict. If two authorized validators claim the same frozen inputs but return semantically incompatible evaluation outputs, create `CONFLICT_DETECTED`; the system must not pick the highest `task_seq` or whichever CAS wins as the truth.

### 6.2 Independent resolution authority

A `CONFLICT_RESOLVED` or `QUARANTINE_RELEASED` event requires a separately authorized reviewer (`role=INDEPENDENT_CONFLICT_REVIEWER`) whose `actor_id` differs from the producer, validator/evaluator(s), plan owner and actor whose write caused the conflict. The reviewer records evidence refs, resolution reason, prior conflict ID, chosen interpretation, policy digest and authorization generation. If no independent authorized reviewer exists, the conflict stays quarantined. Automatic quarantine resolution is disabled in this version.

### 6.3 Task-level pointer

`current_evaluation_id_by_result` and `current_task_evaluation_id` are distinct. The selection policy is immutable/versioned for each applicable projection generation and specifies eligible candidates, priority and deterministic tie-breakers. Incompatible evaluations for the same result and same frozen inputs enter conflict; this is not resolved by sequence priority. `current_task_evaluation_id` is `null` when no candidate is eligible or an applicable barrier blocks adoption.

Dispatch changes `active_execution_id` only; it does not modify the task's current outcome pointer or its `projection_generation`. Adoption/invalidation updates pointer and generation through one atomic compare-and-set against the expected pointer/generation. A pointer can never refer to a superseded, voided or ineligible evaluation. `winner_generation` is replaced here by the unambiguous name `projection_generation`.

## 7. `BASE_ELIGIBLE` and outcome/pattern policy

`BASE_ELIGIBLE` is derived by the coordinator/store and is not producer-writable. It is true only when all are true:

1. current execution/task identity and attempt are valid;
2. execution reached `EXECUTION_STARTED` and accepted a complete terminal result;
3. AUTO correlation and terminal slot checks passed;
4. `planned_mode = observed_mode = AUTHORIZED_REAL_EXECUTION`, backed by required attestations;
5. execution path is accredited;
6. frozen criteria bundle preceded dispatch and all used digest/version values match;
7. validator execution is accepted under the specified evidence contract and evaluation is `VALID` and current for that result;
8. task-sequenced eligibility confirms the result was not late/stale, abandoned or otherwise superseded before terminal acceptance;
9. authorization generations and fencing tokens are current at each required boundary;
10. no conflict/quarantine/tombstone/read barrier or applicable retroactive revocation blocks the result/contribution;
11. no source evaluation, result lineage or effect plan is superseded/voided/retracted;
12. required profile, destination and writer permissions match the frozen package.

If any prerequisite is absent or unverified, `BASE_ELIGIBLE=false`. Failure to establish eligibility never defaults to true.

`TASK_SUCCESS_COUNT` changes only when the task's adopted current result crosses the frozen final-success predicate. It counts a logical task once. `ACTIVE_AUTO_PATTERN_CONTRIBUTION_COUNT` changes only when an eligible unique contribution becomes visible or ceases to be visible. Negative pattern evidence requires a validated, attributable strategy failure under frozen criteria. Provider downtime, rate limits, missing authorization, captor errors, missing output, simulation, uncorrelated response or other non-attributable operational failures do not count as a negative strategy pattern.

## 8. Contributions, plans, visibility barrier, tombstones

### 8.1 Canonical plan states

The only plan states are `PREPARING`, `PARTIAL`, `COMMITTED`, `SUPERSEDED`, `VOIDED`. `PREPARING` is transient; `PARTIAL` is a durable incomplete remnant after a crash. Both are invisible to all selectors. `COMMITTED` means the plan's complete intended changes are durably committed, but an individual contribution is visible only if its own current-eligibility predicate is true. `SUPERSEDED` means replaced by a new plan for the same relevant result lineage. `VOIDED` is terminal and can never reactivate drafts.

Contribution states are `PREPARED`, `ACTIVE`, `RETRACT_PENDING`, `RETRACTED`, `VOIDED`. A `COMMITTED` plan is not itself proof of an active contribution. An `APPLIED` receipt is not proof that a contribution is still visible.

### 8.2 Atomic publication and recovery

Before any change is visible, a durable `effect_plan_id` contains all intended destinations, contribution IDs, source evaluations, previous contributions to retract, effect kinds, provenance, expected `authorization_generation`, expected `projection_generation`, policy version and a digest of the whole plan. Partial writes remain invisible.

The store must atomically publish the complete replacement state, including retracting/superseding prior contributions, committing the successor, updating relevant pointers/generation, and recording the durable recovery journal. If the storage cannot make this atomic, it must use a durable generation barrier/read gate that keeps all affected contributions invisible until the replacement is reconciled. It may never expose both predecessor and successor contributions and “fix” that later by retracting whichever has the smaller sequence.

Recovery from a pre-commit crash either resumes the exact idempotent plan if all source/policy/authorization checks still hold, or moves the plan to `VOIDED`. Recovery after commit reads the commit record and produces the same visible state. A required retract is a persisted recovery obligation created in the same transaction as the invalidation/barrier, not a remembered future action.

### 8.3 Visibility predicate and invalidation

A contribution is visible only if: its plan is fully committed; it is `ACTIVE`; its source evaluation is the current evaluation of the same `result_lineage_id`; it is not superseded/retracted/voided; its lineages/destination/kind pass the uniqueness constraint; authorization is valid for that contribution; and there is no active conflict, tombstone or applicable retroactive revocation barrier.

`CONFLICT_DETECTED` and `TOMBSTONE_COMMITTED` atomically set a read-visibility barrier for the affected result lineage/strategy scope and persist the associated retract/suspend job in the same store transaction. From the event's acceptance point onward no selector may observe the affected contribution, even if physical cleanup has not finished. `L4` becomes false immediately from the same barrier. A crash between event and cleanup cannot expose the contribution.

An authorization revocation prevents new starts/commits using the old generation and voids incomplete plans. Previously committed contributions remain valid by default unless `retroactive_scope` explicitly identifies affected scopes. `retroactive_scope` requires an authorized authority role, policy digest, scope and reason; if it invalidates existing contributions, the visibility barrier and retract job are atomic with accepting the retroactive revocation. It cannot be inferred from a generic revoke event.

Tombstones are durable and scope-bound. They cannot be removed by the same actor that created them. Legitimate recovery from a resolved event conflict is not “resurrection”: it requires `CONFLICT_RESOLVED`, an explicit `restores_event_id`, a new evaluation ID and contribution ID, a new plan, and the same `result_lineage_id` if it is the same evidence. The prior contribution key remains retracted forever. A different strategy lineage is not a substitute for resolving SC-10.

## 9. Authorization generations, fencing, and plan commit

`authorization_generation` guards permissions; `projection_generation` guards selected task/evaluation/effect view. They are separate and neither stands in for task order. Each dispatch, pre-start check, validation/evaluation and effects commit records its authorization generation. The effects commit uses atomic CAS against the expected current authorization generation, expected projection generation, source evaluation ID, policy digests and absence of barriers/tombstones.

If `AUTHORIZATION_REVOKED` advanced the relevant generation before commit, the plan commit is rejected with `AUTHORIZATION_GENERATION_MISMATCH`, the plan becomes `VOIDED`, prepared contributions remain invisible, and no `ACTIVE_AUTO_PATTERN_CONTRIBUTION_COUNT` or `TASK_SUCCESS_COUNT` delta occurs from the blocked plan. A stale fencing token cannot append an effective event or mutate pointers.

The commit is one operation from the reader's perspective. “Check authorization then later commit” without an atomic generation check is forbidden. A `COMMITTED` plan that was valid before a later prospective revoke remains visible unless an explicit retroactive scope applies; any retroactive scope must invoke the barrier rule in §8.3.

## 10. Abandonment, supersession and task reopening

The frozen criteria bundle includes `abandon_timeout_ms`, its clock basis and policy. The store calculates and records `abandon_deadline_at` when dispatch is accepted. `ABANDONED` may be accepted only after the authoritative deadline, while the execution is still abandonable. If the clock is unavailable, auto-abandon is rejected with `CLOCK_UNAVAILABLE`.

An execution may be marked `SUPERSEDED` by an authorized dispatcher when a later attempt becomes active, but this does not itself supersede an already accepted result or evaluation without the corresponding per-entity event and projection rule. Distinguish `EXECUTION_SUPERSEDED`, `EVALUATION_SUPERSEDED`, and `PLAN_SUPERSEDED`; do not reuse one generic state across entities. A terminal output accepted after execution supersession is `LATE_STALE`. `TASK_REOPENED` opens a new attempt with a new execution ID and frozen package; old results stay historical and do not become current automatically.

## 11. Legacy writer isolation and closed writer matrix

The R10 projection namespace rejects legacy writes based only on `result.success`. No old counter/pattern formula can write into R10 projections. Historical records lacking stable identity, correlation, stage, frozen criteria, validation evidence and authorization are `LEGACY_UNATTRIBUTABLE`, not auto-migrated by guessed fields.

The authorized writer matrix is closed:

| Event / operation | Authorized writer | Required preconditions |
|---|---|---|
| `CRITERIA_FROZEN` | Criteria coordinator | Immutable bundle validated and stored before dispatch |
| `DISPATCHED`, `TASK_REOPENED`, `EXECUTION_SUPERSEDED` | Dispatch coordinator | Current authorization generation, new IDs/nonce, bundle/route/profile recorded |
| `EXECUTION_STARTED` | Executor/start observer | Current pre-start authorization check and valid dispatch receipt |
| `SANDBOX_RECORDED` | Sandbox adapter | Diagnostic scope only; never terminal eligibility |
| `CAPTURE_RECEIVED` / `OUTPUT_RECEIVED` | Authorized captor/output adapter | Stable producer event ID, attested mode/path and complete metadata |
| `RESULT_RECORDED` | Result store | Correlation, terminal-slot and completeness checks |
| `VALIDATION_COMPLETED` | Authorized validator | Frozen bundle and recorded used-digest evidence |
| `EVALUATED`, `EVALUATION_REVISED` | Evaluation service / independent reviewer for revisions | Validation accepted; canonical identity; supersession pointer; required reviewer independence |
| `PROJECTION_ADOPTED`, `WINNER_INVALIDATED` | Projection coordinator | Frozen selection policy, task_seq, CAS on pointers and projection generation |
| `ABANDONED` | Supervisor/coordinator | Frozen deadline expired and execution is still abandonable |
| `ATTACHED` | Manual attachment service | Stable attachment ID, MANUAL lane; no AUTO terminal ownership |
| `CONFLICT_DETECTED` | Event/result store | Closed conflict predicate in §6 or §8; barrier and work item atomically persisted |
| `CONFLICT_RESOLVED`, `QUARANTINE_RELEASED` | Independent conflict reviewer | Actor distinct from involved producers/evaluators/plan owner; evidence/reason/policy/generation recorded |
| `AUTHORIZATION_REVOKED` | Authorization authority | Authenticated authority, incremented authorization generation; optional explicit retroactive scope |
| `TOMBSTONE_COMMITTED` | Projection/authority service | Defined scope, author, reason; barrier + recovery obligation atomic |
| `EFFECT_PLAN_PREPARED` | Projection service | Full immutable effect plan; all sources/destinations/generations specified |
| `EFFECTS_COMMITTED` | Projection store | Atomic source/pointer/policy/auth/barrier CAS and complete publication |
| `EFFECT_RETRACTED` | Projection store | Durable cause and obligation ID; atomic visibility change or existing read barrier |
| `PLAN_VOIDED` | Coordinator/store | Invalid source, failed authorization generation, conflict, tombstone or unrecoverable plan |

Any event written by a non-authorized role or stale fencing token is rejected before it can affect projections. The same human may not be both the conflicted producer and the independent resolver.

## 12. Canonical event-transition matrix

| Event | From → to | Durable effect / rejection rule |
|---|---|---|
| `CRITERIA_FROZEN` | no bundle → frozen bundle | Store digests/versions; reject mutation after dispatch |
| `DISPATCHED` | PLANNED → DISPATCHED | Assign task_seq/time/receipt; require authorized generation and route; AUTO conversational needs platform dispatch turn |
| `EXECUTION_STARTED` | DISPATCHED → EXECUTION_STARTED | Recheck authorization/fencing; stale generation rejects start |
| `SANDBOX_RECORDED` | diagnostic event | No automatic result or learning eligibility, with or without sandbox pass |
| `CAPTURE_RECEIVED` / `OUTPUT_RECEIVED` | no result → captured candidate | Require producer_event_id, completeness and attestation; after supersession/abandonment → `LATE_STALE`, no result ID |
| `RESULT_RECORDED` | captured → correlated/frozen | Coordinator verifies parent-turn link, nonce, session, terminal slot and digests; otherwise rejects/`UNCORRELATED` |
| `VALIDATION_COMPLETED` | PENDING → VALIDATING → VALID/INVALID | Exact used digests must match; content conflict under same validator identity rules triggers conflict |
| `EVALUATED` | PENDING → VALID/INVALID/INDETERMINATE/COMPLETED_UNVERIFIED | Derive flags; never trust producer-supplied eligibility |
| `EVALUATION_REVISED` | current eval E1 → E2 successor | Explicit supersedes ID; unique successor; update per-result head with CAS; incompatibility creates conflict |
| `PROJECTION_ADOPTED` | task pointer old/null → eligible candidate | Atomic CAS and policy check; manual or ineligible candidate rejected |
| `WINNER_INVALIDATED` | current candidate → successor/null | Pointer and projection generation updated atomically; old evaluation cannot remain current |
| `TASK_REOPENED` | task gains new attempt | New execution/package; old terminal execution not reopened |
| `EXECUTION_SUPERSEDED` | nonterminal execution → SUPERSEDED | Late future output rejected as LATE_STALE; previously accepted attempt evidence remains immutable |
| `ABANDONED` | eligible in-flight execution → ABANDONED | Only after frozen deadline; absorbent; late output stale |
| `ATTACHED` | new manual record | Independent attachment ID; never claims AUTO terminal slot |
| `CONFLICT_DETECTED` | affected lineage → read-blocked/quarantined | Atomic visibility barrier + durable recovery/retraction job; no downstream contribution read |
| `CONFLICT_RESOLVED` | conflict open → resolved but not automatically active | Requires independent reviewer; restoration requires new evaluation and contribution IDs |
| `QUARANTINE_RELEASED` | quarantined → eligible for fresh explicit adoption check | No direct activation; re-derive all eligibility and require CAS |
| `AUTHORIZATION_REVOKED` | generation g → g+1 | Cancels/voids incomplete old-generation plans; retroactive effects only if scope explicitly says so, via barrier |
| `TOMBSTONE_COMMITTED` | affected scope → read-blocked | Barrier and retraction obligation atomic; same writer cannot revoke tombstone |
| `EFFECT_PLAN_PREPARED` | none → PREPARING/PARTIAL | All prepared effects invisible |
| `EFFECTS_COMMITTED` | PREPARING → COMMITTED | Complete atomic publication only after all guards pass |
| `EFFECT_RETRACTED` | ACTIVE → RETRACTED | Visibility revoked atomically/barrier already in force; idempotent obligation completion |
| `PLAN_VOIDED` | PREPARING/PARTIAL → VOIDED | Terminal; drafts invisible forever |

## 13. Learning levels and causal claims

Levels are current predicates, not irreversible historical flags:

- `L0`: complete result stored with task/execution identity.
- `L1`: L0 plus authenticated dispatch-to-result correlation.
- `L2`: L1 plus frozen package and actual used digests/version match.
- `L3`: L2 plus valid current evaluation.
- `L4`: L3 plus a fully committed, reconciled and currently visible contribution/effect that is eligible for the consumer. The barrier rules make L4 false immediately when a source becomes blocked.
- `L5a`: evidence that a learned delta materially changed a normal production selector decision under a predeclared comparable counterfactual replay, changing only the learned evidence and holding snapshot, candidates, availability, selector and policy versions constant.
- `L5b`: a predefined outcome metric, comparator, window, eligibility filter and sample threshold show improvement in a subsequent objective. `L5b` must ignore contributions/results not L4-valid at the relevant time.

Persistence is not consumption; consumption is not evaluation; evaluation is not application; application is not decision influence; decision influence is not outcome improvement.

## 14. Invariant traceability I1–I12

The literal historical definitions of I1–I12 were not recovered. The labels below are `RECONSTRUCTED_FROM_REVIEW`, not a claim of verbatim historical equivalence. The accompanying review report's invariant descriptions serve as the only available guide. A reviewer must reject any claim of exact historical traceability until the literal source exists.

| ID | Reconstructed invariant summary | Contract guard | Canonical tests |
|---|---|---|---|
| I1 | All automatic effects require universal base eligibility | §§3, 5, 7 | T123–T129, T175–T187 |
| I2 | Automatic terminal slot is isolated and unique per execution/profile/lane | §4.2 | T135–T144, T176, T188 |
| I3 | Output is tied to the authenticated parent dispatch/turn | §4 | T135–T142, T176, T186 |
| I4 | Criteria/checkset/policy used exactly match frozen bundle | §5 | T145–T148, T179, T192 |
| I5 | Task winner uses frozen deterministic policy separate from active attempt | §§6.3, 7 | T150–T154, T157, T178, T191 |
| I6 | Evaluation revision/pointer transition is atomic and uniquely ordered | §§2, 6 | T150, T167, T171, T178, T181 |
| I7 | One active contribution per destination/result lineage/kind | §§1.3, 8 | T155–T159, T177, T192 |
| I8 | Event order, abandonment and supersession are deterministic | §§2, 3.3, 10 | T163, T173, T174, T180, T191 |
| I9 | Invalidation/retraction survives crash and remains invisible during recovery | §8 | T157–T159, T177, T192, T196 |
| I10 | Only authorized writers/independent reviewers can resolve conflicts | §§6.2, 11 | T129, T139, T161–T162, T188, T193 |
| I11 | Legacy result.success path cannot write R10 projections | §11 | T195 |
| I12 | L0–L5b distinguish persistence, decision influence and outcome improvement | §§8.3, 13 | T171–T173, T196 |

## 15. Acceptance and authority boundary

This file is a proposed reconstructed contract awaiting independent static review. It does not claim implementation or test execution. Known dependencies remain `UNPROVEN`: platform-authenticated parent-turn IDs, observed-mode/path attestation, validator execution attestation, durable task sequencer, CAS, transactions/read barriers, fencing, authorization-generation propagation, independent conflict reviewer and real legacy-writer rejection. If any required mechanism is absent, the corresponding operation must fail closed at runtime; the text cannot make it exist.

No execution, tests, builds, M0A access, credential access, canonical document modification or repository mutation is authorized. Government remains `KEEP_BLOCKED`.
