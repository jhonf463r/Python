import os
import time
import numpy as np
import pandas as pd
import pyautogui
from wplay.auth.login import paste_text
from wplay.capture.data_collector import DataCollector
from wplay.strategy.stats_helper import StatsHelper
from wplay.data.db_manager import DBManager
from wplay.data.db_reader import DBReader
from wplay.data.feature_engineer_deep import FeatureEngineerDeep
from wplay.data.model_trainer import ModelTrainer
from wplay.data.transformer_trainer import TransformerTrainer
from wplay.strategy.dqn_agent import DQNAgent
from wplay.strategy.ppo_agent import PPOAgent
from wplay.strategy.strategy_manager_dl import StrategyManagerDL
from wplay.strategy.constants import MONTO_MAX

class BettingEngine:
    def __init__(
        self,
        region_finder,
        data_collector: DataCollector,
        stats_helper: StatsHelper,
        db_manager: DBManager,
        place_bet_fn,
        strategy_manager=None,
        login_handler=None,
        login_url: str = None,
        cooldown: float = 12.0,
        wager_value: int = 500,
    ):
        self.region_finder  = region_finder
        self.data_collector = data_collector
        self.stats_helper   = stats_helper
        self.db_manager     = db_manager
        self.place_bet      = place_bet_fn
        self.login_handler  = login_handler
        self.login_url      = login_url
        self.cooldown       = cooldown
        self.wager_value    = wager_value
        self.saldo          = 0.0
        self.spin_nums      = []
        self.max_drawdown = 0.4  # permítele caer hasta 40 % antes de pausar

        # Gestión de riesgo
        self.stop_loss_daily   = 10000.0
        self.max_drawdown      = 0.2
        self.balance_start_day = 0.0
        self.balance_current   = 0.0
        self.peak_balance      = 0.0
        self.paused            = False
        self._reset_daily()

        # Si me pasan un manager ya entrenado, lo uso directamente
        if strategy_manager is not None:
            self.strategy_manager = strategy_manager
            print("[INIT] StrategyManager preentrenado recibido → omitiendo pipeline offline.")
            return

        # Sino, corro todo el pipeline offline:
        print("[INIT] Reentrenando modelos (pipeline offline)...")
        ROOT_DIR   = os.path.dirname(os.path.dirname(__file__))
        DATA_DIR   = os.path.join(ROOT_DIR, "wplay", "data")
        CLEAN_CSV  = os.path.join(DATA_DIR, "clean_records.csv")
        LSTM_CSV   = os.path.join(DATA_DIR, "lstm_input.csv")
        RL_CSV     = os.path.join(DATA_DIR, "rl_input.csv")

        MODELS_DIR = os.path.join(ROOT_DIR, "wplay", "models")
        LSTM_MODEL = os.path.join(MODELS_DIR, "lstm.h5")
        DQN_MODEL  = os.path.join(MODELS_DIR, "dqn.h5")
        PPO_MODEL  = os.path.join(MODELS_DIR, "ppo.h5")

        # Asegurar carpetas
        for f in (CLEAN_CSV, LSTM_CSV, RL_CSV):
            os.makedirs(os.path.dirname(f), exist_ok=True)
        for m in (LSTM_MODEL, DQN_MODEL, PPO_MODEL):
            os.makedirs(os.path.dirname(m), exist_ok=True)

        # 1) DataCleaner
        print("🔄 DataCleaner: limpiando registros…")
        reader = DBReader()
        df_raw = reader.load_rounds()
        df_raw.to_csv(CLEAN_CSV, index=False)
        print(f"✔️ CSV limpio guardado en '{CLEAN_CSV}'")

        # 2) FeatureEngineerDeep
        print("🔄 FeatureEngineerDeep: generando características…")
        fe = FeatureEngineerDeep(
            clean_csv = CLEAN_CSV,
            lstm_csv  = LSTM_CSV,
            rl_csv    = RL_CSV,
            window    = 50,
            window_rl = 10
        )
        fe.transform()
        print(f"✔️ Características RL en '{RL_CSV}'")

        # 3) Entrenar LSTM
        print("🔄 Entrenando LSTM…")
        if os.path.exists(LSTM_MODEL): os.remove(LSTM_MODEL)
        trainer = ModelTrainer(
            feat_csv      = LSTM_CSV,
            model_type    = 'lstm',
            window        = 50,
            test_size     = 0.2,
            learning_rate = 1e-3,
            epochs        = 20,
            dropout_rate  = 0.2
        )
        trainer.train_model(output_model_path = LSTM_MODEL)
        print(f"✔️ LSTM guardado en '{LSTM_MODEL}'")

        # 4) Entrenar Transformer
        try:
            print("🔄 Entrenando Transformer…")
            transformer = TransformerTrainer(
                feat_csv      = LSTM_CSV,
                model_type    = 'transformer',
                window        = 11,
                test_size     = 0.2,
                learning_rate = 1e-4,
                epochs        = 10,
                dropout_rate  = 0.2
            )
            transformer.train_model(
                output_model_path = os.path.join(MODELS_DIR, "transformer.h5")
            )
            print("✔️ Transformer guardado.")
        except Exception as e:
            print("[WARN] TransformerTrainer falló:", e)

        # 5) Preparar datos RL y pre-entrenar agentes offline
        df_rl = pd.read_csv(RL_CSV)
        cats = StrategyManagerDL.CATEGORIES
        # Mapeo, entrenamiento offline DQN y PPO...
        # Instanciar StrategyManagerDL
        self.strategy_manager = StrategyManagerDL(
            lstm_path    = LSTM_MODEL,
            rl_agent_dqn = dqn,
            rl_agent_ppo = ppo,
            window_lstm  = 50,
            window_rl    = 10
        )
        print("✅ StrategyManagerDL inicializado.")
    def monitor(self):
        if self.offline_mode:
            return self.backtest()

        # Loop real-time...
        # Mostrar métricas en tiempo real
        self.report_metrics()
        # Resto de monitor()...
    def backtest(self):
        records = self.db_manager.load_all()
        balances = [r['saldo'] for r in records]
        returns = np.diff(balances) / balances[:-1]
        sharpe = np.mean(returns) / (np.std(returns) + 1e-8) * np.sqrt(252)
        max_dd = max((max(balances[:i]) - balances[i]) / max(balances[:i]) for i in range(len(balances)))
        win_rate = sum(r['ganancia']>0 for r in records)/len(records)
        print(f"Backtest → Sharpe: {sharpe:.2f}, MaxDD: {max_dd:.2%}, Win-rate: {win_rate:.2%}")
        return {'sharpe':sharpe, 'max_dd':max_dd, 'win_rate':win_rate}
    def report_metrics(self):
        # Llamar vía python_user_visible si queremos gráficas
        print(f"ε={self.strategy_manager.dqn_agent.epsilon:.3f} | Q_max={self.strategy_manager.last_q_max:.2f} | V_max={self.strategy_manager.last_v_max:.2f}")

    def _reset_daily(self):
        self.balance_start_day = self.balance_current
        self.peak_balance      = self.balance_current

    def _update_balance(self, gain: float):
        self.balance_current += gain
        # Aquí se actualiza el pico si y solo si hay un nuevo máximo real
        self.peak_balance = max(self.peak_balance, self.balance_current)

    def _check_risk(self):
        # Stop-loss diario
        daily_loss = self.balance_start_day - self.balance_current
        if daily_loss >= self.stop_loss_daily:
            print(f"⚠ Stop-loss diario alcanzado: pérdida {daily_loss}")
            self.paused = True

        # Drawdown (solo si peak_balance > 0)
        if self.peak_balance > 0:
            drawdown = (self.peak_balance - self.balance_current) / self.peak_balance
            if drawdown >= self.max_drawdown:
                print(f"⚠ Drawdown máximo alcanzado: {drawdown * 100:.1f}%")
                self.paused = True
    def relogin(self) -> bool:
        """
        Tras 3 min sin detección de número o inactividad,
        refresca la página y delega el login a LoginAutomation.
        """
        import pyautogui

        # 1) Alerta y refresh
        print("[ENGINE][WARN] Sin detección → iniciando relogin…")
        pyautogui.press("f5")
        time.sleep(5)

        # 2) Delegar login completo
        if not self.login_handler.login_or_continue(timeout=60):
            print("[ENGINE][ERROR] Relogin fallido: login_or_continue devolvió False.")
            return False

        # 3) Asegurar que estamos de nuevo en la pantalla de apuestas
        #    Podemos esperar el botón 'apostar' o tu selector principal
        start = time.time()
        while time.time() - start < 30:
            det = self.region_finder.find_all_regions()
            if "apostar" in det or "speed auto roulette" in det:
                print("[ENGINE] Relogin exitoso, reanudando apuestas.")
                # Reset de buffers para no repetir spins viejos
                self.data_collector.reset_spin_buffer()
                self.spin_nums.clear()
                # Reiniciar timeout de último número
                self.last_num_time = time.time()
                return True
            time.sleep(0.5)

        print("[ENGINE][ERROR] Relogin fallido: no detecté la UI de apuestas tras login.")
        return False


    def run(self):
        print("🎲 Iniciando BettingEngine…")

        # 🔧 Inicializar balances al saldo real antes de entrar al bucle
        self.balance_current   = self.saldo
        self.balance_start_day = self.saldo
        self.peak_balance      = self.saldo

        last_bet_time    = 0.0
        last_num_time    = time.time()
        apuesta_en_curso = False
        last_cat = last_strat = None
        last_amt = 0

        while True:
            # 1) Pausa por límite de riesgo
            if self.paused:
                print("⚠ Estrategia pausada por límite de riesgo. Esperando 5 min para reintentar…")
                time.sleep(300)       # espera 5 min
                # Opcional: al pasar ese tiempo, reactivar y reiniciar cuenta diaria
                self.paused = False
                self._reset_daily()
                continue
            # 2) Detectar regiones UI
            det = self.region_finder.find_all_regions()

            # 3) Si no hay giro en 3 min → relogin
            if time.time() - last_num_time > 3 * 60:
                self.relogin()
                self.data_collector.reset_spin_buffer()
                self.spin_nums.clear()
                last_num_time = time.time()
                last_bet_time = 0.0
                continue

            # 4) Clic en "clic" (plantillas)
            if "clic" in det:
                self.region_finder.click_region("clic")
                time.sleep(0.2)
                continue

            # 5) Acumular stats de giro
            if "giro" in det:
                rois = self.data_collector.regions.get("ruleta", [])
                if rois:
                    self.data_collector.accumulate_spin(rois[0])
                else:
                    print("[ENGINE][WARN] ROI 'ruleta' no encontrado.")

            # 6) Cooldown entre apuestas
            now = time.time()
            if now - last_bet_time < self.cooldown:
                time.sleep(0.2)
                continue

            # 7) Esperar botón "apostar"
            if "apostar" not in det:
                time.sleep(0.2)
                continue

            # 8) Leer resultado OCR
            numero, jugadores = self.data_collector.read_result(det)
            if numero is None:
                time.sleep(0.2)
                continue
            last_num_time = now

            # 9) Calcular ganancia previa
            gain = 0.0
            if apuesta_en_curso:
                win, gain = self.data_collector.compute_gain(
                    numero, last_cat, last_amt, self.wager_value
                )
                print(f"[DEBUG] Resultado previo: win={win}, gain={gain}")

            # 10) Obtener stats de giro
            avg_vel, direction = self.data_collector.get_spin_stats()
            print(f"[DEBUG] Velocidad: {avg_vel:.2f}, dirección: {direction}")

            # 11) Construir registro
            registro = {
                "fecha_hora": time.strftime("%Y-%m-%d %H:%M:%S"),
                "numero": numero,
                "jugadores_presentes": jugadores,
                "ganancia": gain,
                "saldo_anterior": self.saldo,
                "velocity": avg_vel,
                "direction": direction,
                "strategy": last_strat,
                "fichas": last_amt,
                "saldo": self.saldo + gain,
                "opcion_apuesta": last_cat
            }

            # 12) Historial de números y guardar en BD
            self.spin_nums.append(numero)
            if len(self.spin_nums) > self.strategy_manager.window_rl:
                self.spin_nums.pop(0)
            registro["numero_hist"] = list(self.spin_nums)
            self.db_manager.guardar_registro(registro)
            print(">> Registro guardado:", registro)

            # 13) Alimentar al manager y entrenar
            self.strategy_manager.add_record(registro)

            # 14) 🔧 Actualizar balance y pico histórico únicamente vía _update_balance
            self._update_balance(gain)
            self._check_risk()
            if self.paused:
                continue

            # 15) Elegir y ejecutar apuesta
            cat_pred, amt, used = self.strategy_manager.choose()
            print(f"[CHOICE] {used} → categoría={cat_pred}, fichas={amt}")
            label = "[SIM]" if getattr(self.region_finder, "simulate", True) else "[REAL]"
            print(f"{label} Apostando {amt} ficha(s) a '{cat_pred}'")
            self.place_bet(cat_pred, amt)

            # 16) Actualizar estado post-apuesta
            self.saldo = registro["saldo"]
            apuesta_en_curso = True
            last_cat, last_amt, last_strat = cat_pred, amt, used
            last_bet_time = now

            # 17) Reset buffer y breve espera
            self.data_collector.reset_spin_buffer()
            time.sleep(0.2)
