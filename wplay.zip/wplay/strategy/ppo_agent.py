import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
import os

class PPOAgent:
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        lr_actor: float = 1e-4,
        lr_critic: float = 3e-4,
        gamma: float = 0.99,
        eps_clip: float = 0.2,
        K_epochs: int = 4,
        # Mejora 1: scheduler opcional de learning rate
        use_lr_schedule: bool = False,
        lr_decay_steps: int = 10000,
        lr_decay_rate: float = 0.9,
        path_actor: str = None,
        path_critic: str = None,
    ):
        """
        :param state_dim: Dimensión del vector de estado.
        :param action_dim: Número de acciones posibles.
        :param lr_actor: Learning rate inicial para el actor.
        :param lr_critic: Learning rate inicial para el critic.
        :param gamma: Factor de descuento.
        :param eps_clip: Epsilon para el clipping en PPO.
        :param K_epochs: Épocas de actualización por batch.
        :param use_lr_schedule: Activa decay exponencial en los LR.
        :param lr_decay_steps: Pasos para el decay de learning rate.
        :param lr_decay_rate: Factor de decay de learning rate.
        :param path_actor: Ruta para cargar pesos del actor.
        :param path_critic: Ruta para cargar pesos del critic.
        """
        self.state_dim   = state_dim
        self.action_dim  = action_dim
        self.gamma       = gamma
        self.eps_clip    = eps_clip
        self.K_epochs    = K_epochs

        # Configurar learning rate / scheduler
        if use_lr_schedule:
            actor_lr = tf.keras.optimizers.schedules.ExponentialDecay(
                initial_learning_rate=lr_actor,
                decay_steps=lr_decay_steps,
                decay_rate=lr_decay_rate,
                staircase=True
            )
            critic_lr = tf.keras.optimizers.schedules.ExponentialDecay(
                initial_learning_rate=lr_critic,
                decay_steps=lr_decay_steps,
                decay_rate=lr_decay_rate,
                staircase=True
            )
        else:
            actor_lr = lr_actor
            critic_lr = lr_critic

        # Construir redes actor y critic
        self.actor   = self._build_actor(actor_lr)
        self.critic  = self._build_critic(critic_lr)

        # Cargar pesos si existen
        self.path_actor  = path_actor
        self.path_critic = path_critic
        if self.path_actor and os.path.exists(self.path_actor):
            self.actor.load_weights(self.path_actor)
        if self.path_critic and os.path.exists(self.path_critic):
            self.critic.load_weights(self.path_critic)

        # Buffers temporales para entrenamiento online
        self.buffer_states   = []
        self.buffer_actions  = []
        self.buffer_logprobs = []
        self.buffer_rewards  = []
        self.buffer_dones    = []
        self.buffer_values   = []

    def _build_actor(self, lr) -> Sequential:
        model = Sequential([
            Dense(128, activation='relu', input_shape=(self.state_dim,)),
            Dense(64, activation='relu'),
            Dense(self.action_dim, activation='softmax'),
        ])
        model.compile(optimizer=Adam(learning_rate=lr), loss='categorical_crossentropy')
        return model

    def _build_critic(self, lr) -> Sequential:
        model = Sequential([
            Dense(128, activation='relu', input_shape=(self.state_dim,)),
            Dense(64, activation='relu'),
            Dense(1, activation='linear'),
        ])
        model.compile(optimizer=Adam(learning_rate=lr), loss='mse')
        return model

    def select_action(self, state: np.ndarray):
        """
        Devuelve (action_idx, log_prob, value) y almacena en buffers.
        """
        state_vect = state.reshape(1, -1)
        probs = self.actor.predict(state_vect, verbose=0)[0]
        action_idx = np.random.choice(self.action_dim, p=probs)
        log_prob = np.log(probs[action_idx] + 1e-8)
        value = float(self.critic.predict(state_vect, verbose=0)[0])

        # Guardar en buffers
        self.buffer_states.append(state_vect.flatten())
        self.buffer_actions.append(action_idx)
        self.buffer_logprobs.append(log_prob)
        self.buffer_values.append(value)

        return action_idx, log_prob, value

    def store_transition(self, state, action, reward, next_state, done, drawdown=0.0):
        # Reward shaping penalizando drawdown
        shaped = np.clip(reward, -1, 1) - 0.1 * drawdown
        self.buffer.append((state, action, shaped, next_state, done))
    def compute_values(self, states):
        # Normalizar outputs del critic
        values = self.critic(np.array(states))
        mean, std = tf.reduce_mean(values), tf.math.reduce_std(values)
        normed = (values - mean) / (std + 1e-8)
        return tf.clip_by_value(normed, -1, 1)
    def update(self):
        """
        Actualiza actor y critic usando los buffers.
        """
        states       = np.vstack(self.buffer_states)
        actions      = np.array(self.buffer_actions)
        old_logprobs = np.array(self.buffer_logprobs)
        rewards      = np.array(self.buffer_rewards, dtype=np.float32)
        dones        = np.array(self.buffer_dones, dtype=np.bool_)
        values       = np.array(self.buffer_values, dtype=np.float32).flatten()

        # Calcular returns
        returns = []
        discounted_sum = 0.0
        for r, done in zip(reversed(rewards), reversed(dones)):
            if done:
                discounted_sum = 0.0
            discounted_sum = r + self.gamma * discounted_sum
            returns.insert(0, discounted_sum)
        returns = np.array(returns, dtype=np.float32)

        # Calcular ventajas normalizadas
        advantages = returns - values
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # Update de learning rate si scheduler
        if self.use_lr_schedule:
            for epoch in range(self.K_epochs):
                new_lr = self.lr_scheduler(epoch)
                self.actor.optimizer.lr.assign(new_lr)
                self.critic.optimizer.lr.assign(new_lr)

        # Entrenamiento actor/critic
        for _ in range(self.K_epochs):
            # Actor
            with tf.GradientTape() as tape_actor:
                probs = self.actor(states, training=True)
                action_probs = tf.reduce_sum(
                    probs * tf.one_hot(actions, self.action_dim), axis=1)
                new_logprobs = tf.math.log(action_probs + 1e-8)
                ratios = tf.exp(new_logprobs - old_logprobs)
                surr1 = ratios * advantages
                surr2 = tf.clip_by_value(
                    ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
                loss_actor = -tf.reduce_mean(tf.minimum(surr1, surr2))
            grads_actor = tape_actor.gradient(
                loss_actor, self.actor.trainable_variables)
            self.actor.optimizer.apply_gradients(
                zip(grads_actor, self.actor.trainable_variables))

            # Critic
            with tf.GradientTape() as tape_critic:
                value_preds = tf.squeeze(self.critic(states, training=True))
                loss_critic = tf.reduce_mean(
                    tf.square(returns - value_preds))
            grads_critic = tape_critic.gradient(
                loss_critic, self.critic.trainable_variables)
            self.critic.optimizer.apply_gradients(
                zip(grads_critic, self.critic.trainable_variables))

        # Limpiar buffers
        self.buffer_states.clear()
        self.buffer_actions.clear()
        self.buffer_logprobs.clear()
        self.buffer_rewards.clear()
        self.buffer_dones.clear()
        self.buffer_values.clear()

        return float(loss_actor), float(loss_critic), float(np.mean(returns))
    def train_offline(
        self,
        states: np.ndarray,
        actions: np.ndarray,
        returns: np.ndarray,
        advantages: np.ndarray,
        old_logprobs: np.ndarray,
        epochs: int = 1,
        batch_size: int = 64
    ):
        """
        Entrenamiento offline usando los arrays dados.
        """
        for _ in range(epochs):
            # Actor
            with tf.GradientTape() as tape_actor:
                probs = self.actor(states, training=True)
                action_probs = tf.reduce_sum(
                    probs * tf.one_hot(actions, self.action_dim), axis=1)
                new_logprobs = tf.math.log(action_probs + 1e-8)
                ratios = tf.exp(new_logprobs - old_logprobs)
                surr1 = ratios * advantages
                surr2 = tf.clip_by_value(
                    ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
                loss_actor = -tf.reduce_mean(tf.minimum(surr1, surr2))
            grads_actor = tape_actor.gradient(
                loss_actor, self.actor.trainable_variables)
            self.actor.optimizer.apply_gradients(
                zip(grads_actor, self.actor.trainable_variables))

            # Critic
            with tf.GradientTape() as tape_critic:
                value_preds = tf.squeeze(self.critic(states, training=True))
                loss_critic = tf.reduce_mean(
                    tf.square(returns - value_preds))
            grads_critic = tape_critic.gradient(
                loss_critic, self.critic.trainable_variables)
            self.critic.optimizer.apply_gradients(
                zip(grads_critic, self.critic.trainable_variables))

    def save(self, path_actor: str, path_critic: str):
        os.makedirs(os.path.dirname(path_actor), exist_ok=True)
        os.makedirs(os.path.dirname(path_critic), exist_ok=True)
        self.actor.save(path_actor)
        self.critic.save(path_critic)

    def load(self, path_actor: str, path_critic: str):
        if os.path.exists(path_actor):
            self.actor.load_weights(path_actor)
        if os.path.exists(path_critic):
            self.critic.load_weights(path_critic)

    def log_metrics(
        self,
        episode: int,
        total_reward: float,
        loss_actor: float,
        loss_critic: float,
        avg_return: float
    ):
        print(
            f"[PPO] Episodio {episode} | Reward total: {total_reward:.2f} | "
            f"Return_prom: {avg_return:.2f} | Actor_loss: {loss_actor:.4f} | "
            f"Critic_loss: {loss_critic:.4f}"
        )
