import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from wplay.data.feature_engineer_deep import MAX_JUGADORES
from wplay.strategy.constants import MONTO_MAX  # MONTO_MAX = número máximo de fichas por apuesta

class StrategyManagerDL:
    """
    Estrategia híbrida DQN + PPO. Contiene:
      - Un DQNAgent (self.rl_agent_dqn)
      - Un PPOAgent (self.rl_agent_ppo)

    Ambos aprenden en paralelo (DQN con replay buffer + PPO con su propio buffer).
    Al elegir → comparamos Q(s, a)_DQN con V(s)_PPO (ambos normalizados).

    Mejoras:
      - Clipping de recompensa a [-1,1]
      - Normalización de Q y V para comparación justa
      - Confianza como |Q_norm - V_norm|
      - Umbral de confianza para escoger PPO
      - Bet-sizing dinámico según confianza
    """

    CATEGORIES = ["rojo", "negro", "par", "impar", "1-18", "19-36"]

    def __init__(
        self,
        lstm_path: str,
        rl_agent_dqn,
        rl_agent_ppo,
        window_lstm: int = 50,
        window_rl: int = 10,
        confidence_threshold: float = 0.1,
        bet_scale_factor: float = 1.0
    ):
        # 1) Cargar LSTM si corresponde
        self.lstm = load_model(lstm_path) if lstm_path else None

        # 2) Instancias de agentes
        self.rl_agent_dqn = rl_agent_dqn
        self.rl_agent_ppo = rl_agent_ppo

        # 3) Ventanas de historial
        self.window_lstm = window_lstm
        self.window_rl   = window_rl

        # 4) Parámetros de selección avanzada
        self.confidence_threshold = confidence_threshold
        self.bet_scale_factor = bet_scale_factor

        # 5) Construir action_map
        self.action_map = []
        for cat in StrategyManagerDL.CATEGORIES:
            for fichas in range(1, MONTO_MAX + 1):
                self.action_map.append((cat, fichas))
        self.action_dim = len(self.action_map)

        # 6) Ajustar action_dim en agentes
        self.rl_agent_dqn.action_dim = self.action_dim
        self.rl_agent_ppo.action_dim = self.action_dim

        # 7) Historial y estado previo
        self.registros         = []
        self.last_state        = None
        self.last_chosen_idx   = None
        self.last_algo         = None
        self.last_ppo_logprob  = None
        self.last_ppo_value    = None

    def add_record(self, registro: dict):
        """
        Tras cada giro/apuesta:
        1) Añadir registro
        2) Si hay acción anterior, calcular reward y almacenar en DQN/PPO
        3) Entrenar DQN/PPO online con prints de loss
        4) Actualizar last_state
        """
        # 1) Historial
        self.registros.append(registro)
        if len(self.registros) > self.window_lstm:
            self.registros.pop(0)

        # 2) Estado actual
        current_state = self._build_state_vector(self.registros[-1])

        # 3) Si existe acción previa
        if self.last_state is not None and self.last_chosen_idx is not None:
            monto_ant = (self.last_chosen_idx % MONTO_MAX) + 1
            gan = float(registro.get("ganancia", 0.0))

            # clipping y normalización de reward
            reward = np.clip(gan / monto_ant, -1.0, 1.0)
            done = False

            # DQN
            if hasattr(self.rl_agent_dqn, "store_transition"):
                self.rl_agent_dqn.store_transition(
                    state      = np.array(self.last_state, dtype=np.float32),
                    action     = int(self.last_chosen_idx),
                    raw_reward = reward,
                    next_state = np.array(current_state, dtype=np.float32),
                    done       = done
                )
                if self.rl_agent_dqn.buffer.size() >= 32:
                    loss_dqn = self.rl_agent_dqn.train()
                    print(f"[DQN TRAIN] loss = {loss_dqn:.4f}")

            # PPO
            if hasattr(self.rl_agent_ppo, "store_transition"):
                self.rl_agent_ppo.store_transition(
                    reward = reward,
                    done   = done,
                    value  = self.last_ppo_value
                )
                if len(self.rl_agent_ppo.buffer_states) >= 32:
                    pl, vl, ent = self.rl_agent_ppo.update()
                    print(f"[PPO TRAIN] policy_loss = {pl:.4f} | value_loss = {vl:.4f} | entropy = {ent:.4f}")

        # 4) Actualizar last_state
        self.last_state = current_state

    def _build_state_vector(self, history, saldo_history, vel_history, win_times):
        vec = []
        # Números recientes
        vec.extend(history[-10:])
        # Tiempo desde última victoria
        if win_times:
            vec.append(time.time() - win_times[-1])
        else:
            vec.append(1e6)
        # Velocidades históricas
        vec.extend(vel_history[-5:])
        # Drawdown actual
        peak = max(saldo_history)
        drawdown = (peak - saldo_history[-1]) / peak if peak>0 else 0
        vec.append(drawdown)
        return np.array(vec, dtype=np.float32)
    

    def bet_amount(self, strategy, last_win):
        confidence = abs(self.last_q_max - self.last_v_max)
        base = self.base_bet
        return int(base * (1 + confidence * self.bet_scale))

    def choose(self) -> tuple:
        """
        1) DQN → idx + Q_norm(s,idx)
        2) PPO → idx + V_norm(s)
        3) Confianza = |Q_norm - V_norm|
        4) Si confianza>=threshold → PPO, else DQN
        5) Bet-sizing: monto*(1+conf*bet_scale_factor)
        6) Devolver (cat, monto, etiqueta)
        """
        import numpy as np

        # preparar estado
        state = self.last_state

        # --- DQN ---
        dqn_idx = self.rl_agent_dqn.select_action(state)
        q_vals = self.rl_agent_dqn.model.predict(state[None], verbose=0)[0]
        q = float(q_vals[dqn_idx])
        q_norm = (q - np.min(q_vals)) / (np.ptp(q_vals) + 1e-8)

        # --- PPO ---
        ppo_idx, ppo_logp, ppo_val = self.rl_agent_ppo.select_action(state)
        v = float(ppo_val)
        # normalizar V usando su propio rango o el de Q para comparabilidad
        v_norm = (v - np.min(q_vals)) / (np.ptp(q_vals) + 1e-8)

        # confianza y decisión
        confidence = abs(q_norm - v_norm)
        if confidence >= self.confidence_threshold:
            chosen_idx = ppo_idx
            algo = 'ppo'
        else:
            chosen_idx = dqn_idx
            algo = 'dqn'

        # bet-sizing dinámico
        base_monto = (chosen_idx % MONTO_MAX) + 1
        monto = int(base_monto * (1 + confidence * self.bet_scale_factor))
        monto = max(1, min(monto, MONTO_MAX))

        # mapear a categoría
        cat = StrategyManagerDL.CATEGORIES[chosen_idx // MONTO_MAX]

        # debug prints
        print(f"[COMPARE] Q_norm={q_norm:.4f}, V_norm={v_norm:.4f}, conf={confidence:.4f}")
        print(f"[CHOICE] {algo.upper()} wins idx={chosen_idx}, bet={monto}")

        # guardar para add_record
        self.last_chosen_idx  = chosen_idx
        self.last_algo        = algo
        self.last_ppo_value   = v
        self.last_ppo_logprob = ppo_logp

        return cat, monto, f'dqn-ppo[{algo}]'
