import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import load_model, clone_model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import MeanSquaredError
from wplay.strategy.prioritized_replay_buffer import PrioritizedReplayBuffer
from wplay.strategy.constants import MONTO_MAX


def build_q_network(state_dim: int, action_dim: int) -> tf.keras.Model:
    """
    Construye una red Q simple de dos capas ocultas para DQN.
    """
    model = Sequential([
        Input(shape=(state_dim,)),
        Dense(64, activation='relu'),
        Dense(64, activation='relu'),
        Dense(action_dim, activation='linear'),
    ])
    return model


class DQNAgent:
    """
    Agente DQN con Double DQN y Prioritized Experience Replay,
    con:
      - Escalado/clip de recompensas según MONTO_MAX
      - Decaimiento de ε en fases con mínimo residual
      - Polyak averaging de target network
      - Scheduler opcional de learning rate
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        learning_rate: float = 1e-3,
        gamma: float = 0.99,
        epsilon_start: float = 1.0,
        epsilon_mid: float = 0.5,
        epsilon_final: float = 0.05,
        decay_steps_phase1: int = 10000,
        decay_steps_phase2: int = 40000,
        tau: float = 0.005,
        use_lr_scheduler: bool = True,
        buffer_size: int = 100000,
        batch_size: int = 64,
        per_alpha: float = 0.6,
        per_beta_start: float = 0.4,
        per_beta_frames: int = 100000
    ):
        # dimensiones y parámetros
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma

        # ε-greedy por fases
        self.epsilon = epsilon_start
        self.eps_start = epsilon_start
        self.eps_mid = epsilon_mid
        self.eps_final = epsilon_final
        self.phase1 = decay_steps_phase1
        self.phase2 = decay_steps_phase2
        self.step_count = 0

        # redes neural y target
        self.q_network = build_q_network(state_dim, action_dim)
        self.target_network = build_q_network(state_dim, action_dim)
        self.target_network.set_weights(self.q_network.get_weights())

        # Replay buffer con PER
        self.memory = PrioritizedReplayBuffer(
            size=buffer_size,
            alpha=per_alpha,
            beta_start=per_beta_start,
            beta_frames=per_beta_frames
        )
        self.batch_size = batch_size

        # optimizador y scheduler
        self.optimizer = Adam(learning_rate)
        if use_lr_scheduler:
            self.lr_scheduler = tf.keras.optimizers.schedules.ExponentialDecay(
                initial_learning_rate=learning_rate,
                decay_steps=10000,
                decay_rate=0.5,
                staircase=True
            )
        else:
            self.lr_scheduler = None

        # Polyak averaging
        self.tau = tau

    def choose_action(self, state: np.ndarray) -> int:
        """
        Selección ε-greedy por fases según step_count.
        """
        # actualizar epsilon
        if self.step_count < self.phase1:
            decay = (self.eps_mid - self.eps_start) / self.phase1
            self.epsilon = max(self.eps_mid, self.eps_start + decay * self.step_count)
        elif self.step_count < self.phase2:
            decay = (self.eps_final - self.eps_mid) / (self.phase2 - self.phase1)
            self.epsilon = max(
                self.eps_final,
                self.eps_mid + decay * (self.step_count - self.phase1)
            )
        # acción
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.action_dim)
        q_vals = self.q_network(np.expand_dims(state, 0)).numpy()[0]
        return int(np.argmax(q_vals))

    def store_transition(
        self,
        state: np.ndarray,
        action: int,
        raw_reward: float,
        next_state: np.ndarray,
        done: bool
    ) -> None:
        """
        Escala y clippea la recompensa, y añade la transición al buffer.
        """
        r = raw_reward / MONTO_MAX
        r = np.clip(r, -1.0, 1.0)
        self.memory.add(state, action, r, next_state, done)

    def train_step(self) -> float:
        """
        Un paso de entrenamiento: muestreo PER, cálculo del target, gradientes,
        actualización de target network y scheduler.
        """
        # beta annealing
        beta = self.memory.beta_by_frame(self.step_count)
        # sample PER
        states, actions, rewards, next_states, dones, weights, indices = \
            self.memory.sample(self.batch_size, beta)

        # scheduler de LR
        if self.lr_scheduler:
            lr = self.lr_scheduler(self.step_count)
            self.optimizer.lr.assign(lr)

        # cálculo de target Q (Double DQN)
        next_q_online = self.q_network(next_states)
        next_actions = tf.argmax(next_q_online, axis=1)
        next_q_target = self.target_network(next_states)
        target_q = rewards + (1 - dones) * self.gamma * tf.gather(
            next_q_target, next_actions, axis=1, batch_dims=1
        )
        target_q = tf.stop_gradient(target_q)

        with tf.GradientTape() as tape:
            q_vals = self.q_network(states)
            q_taken = tf.reduce_sum(
                q_vals * tf.one_hot(actions, self.action_dim), axis=1
            )
            td_error = q_taken - target_q
            loss = tf.reduce_mean(weights * tf.square(td_error))

        grads = tape.gradient(loss, self.q_network.trainable_variables)
        self.optimizer.apply_gradients(
            zip(grads, self.q_network.trainable_variables)
        )

        # actualizar prioridades PER
        self.memory.update_priorities(indices, np.abs(td_error.numpy()) + 1e-6)

        # Polyak averaging de target network
        for w_q, w_t in zip(
            self.q_network.weights, self.target_network.weights
        ):
            w_t.assign(self.tau * w_q + (1 - self.tau) * w_t)

        self.step_count += 1
        return float(loss)

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.q_network.save(path)

    def load(self, path: str) -> None:
        if os.path.exists(path):
            self.q_network = load_model(path, compile=False)
            self.target_network = clone_model(self.q_network)
            self.target_network.set_weights(self.q_network.get_weights())
