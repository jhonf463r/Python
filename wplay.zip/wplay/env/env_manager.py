import os
import logging
import pandas as pd
import numpy as np
from typing import Tuple, Any, Optional
from wplay.features import FeaturePipeline

class EnvModel:
    """
    Simulador de entorno basado en registros históricos de ruleta.

    - Usa un FeaturePipeline unificado para preprocesar estados.
    - API tipo Gym:
        * reset() -> estado inicial procesado
        * step(action) -> (next_state, reward, done)
    """

    _warned_alignment = False  # Para avisar solo una vez

    def __init__(
        self,
        state_csv: str,
        transition_csv: str,
        shuffle: bool = False,
        seed: Optional[int] = None
    ):
        # 1) Validar existencia de archivos
        if not os.path.exists(state_csv):
            raise FileNotFoundError(f"EnvModel: no encontré {state_csv}")
        if not os.path.exists(transition_csv):
            raise FileNotFoundError(f"EnvModel: no encontré {transition_csv}")

        # 2) Detectar CSV invertidos
        cols0 = pd.read_csv(state_csv, nrows=0).columns
        if 'reward' in cols0 or 'done' in cols0:
            logging.warning(
                "EnvModel: detectado reward/done en state_csv; intercambiando roles"
            )
            state_csv, transition_csv = transition_csv, state_csv

        # 3) Semilla
        if seed is not None:
            np.random.seed(seed)

        # 4) Cargar estados (parseo fecha_hora)
        self.df_state = pd.read_csv(
            state_csv,
            parse_dates=['fecha_hora'],
            low_memory=False
        )
        logging.debug(f"EnvModel: estado columnas = {self.df_state.columns.tolist()}")

        # 5) Cargar transiciones
        self.df_trans = pd.read_csv(transition_csv, low_memory=False)
        logging.debug(f"EnvModel: transiciones columnas = {self.df_trans.columns.tolist()}")

        # 6) Alineación temporal o por índice
        if 'fecha_hora' in self.df_state.columns and 'fecha_hora' in self.df_trans.columns:
            # Ambos tienen fecha_hora: merge
            self.df_trans['fecha_hora'] = pd.to_datetime(
                self.df_trans['fecha_hora'], errors='coerce'
            )
            merged = pd.merge(
                self.df_state[['fecha_hora']],
                self.df_trans,
                on='fecha_hora',
                how='inner',
                sort=False
            )
            if len(merged) != len(self.df_state) and not EnvModel._warned_alignment:
                logging.warning(
                    f"EnvModel: tras merge por fecha_hora, estados={len(self.df_state)}, "
                    f"transiciones={len(merged)}; recortando al mínimo común."
                )
                EnvModel._warned_alignment = True

            min_len = min(len(self.df_state), len(merged))
            self.df_state = self.df_state.iloc[:min_len].reset_index(drop=True)
            self.df_trans = merged.iloc[:min_len].reset_index(drop=True)

        else:
            # Sin fecha_hora: alineación por índice
            if len(self.df_state) != len(self.df_trans) and not EnvModel._warned_alignment:
                logging.warning(
                    f"EnvModel: no hay 'fecha_hora' en ambas; filas estado={len(self.df_state)}, "
                    f"transiciones={len(self.df_trans)}; recortando al mínimo común."
                )
                EnvModel._warned_alignment = True

            min_len = min(len(self.df_state), len(self.df_trans))
            self.df_state = self.df_state.iloc[:min_len].reset_index(drop=True)
            self.df_trans = self.df_trans.iloc[:min_len].reset_index(drop=True)

        # 7) Índices internos
        self._max_index     = min_len - 1
        self._current_index = 0

        # 8) Columnas crudas de estado (sin control ni fecha_hora)
        self._raw_cols = [
            c for c in self.df_state.columns
            if c not in ('action', 'reward', 'done', 'fecha_hora')
               and not c.startswith('next_')
        ]

        # 9) Shuffle opcional
        if shuffle:
            idx = np.random.permutation(min_len)
            self.df_state = self.df_state.iloc[idx].reset_index(drop=True)
            self.df_trans = self.df_trans.iloc[idx].reset_index(drop=True)

        # 10) Separar feats numéricas / categóricas
        numeric_feats = [
            c for c in self._raw_cols
            if pd.api.types.is_numeric_dtype(self.df_state[c])
        ]
        categ_feats = [
            c for c in self._raw_cols
            if pd.api.types.is_object_dtype(self.df_state[c])
        ]

        # 11) Pipeline y state_dim
        self.pipeline = FeaturePipeline(numeric_feats, categ_feats)
        self.pipeline.fit_offline(self.df_state)
        sample = self.df_state.loc[[0], self._raw_cols]
        self.state_dim = self.pipeline.transform(sample).shape[1]

        # 12) Determinar action_dim y validar reward/done
        if 'action' in self.df_trans.columns:
            self.action_dim = int(self.df_trans['action'].max()) + 1
        else:
            raise ValueError("EnvModel: transition_csv requiere columna 'action'.")

        for col in ('reward', 'done'):
            if col not in self.df_trans.columns:
                raise ValueError(f"EnvModel: transition_csv requiere columna '{col}'")


    def reset(self) -> np.ndarray:
        """Reinicia índice y devuelve estado inicial procesado."""
        self._current_index = 0
        row = self.df_state.loc[[0], self._raw_cols]
        return self.pipeline.transform(row).astype(np.float32).flatten()

    def step(self, action: Any) -> Tuple[np.ndarray, float, bool]:
        """Avanza un paso: devuelve (next_state, reward, done)."""
        reward = float(self.df_trans.loc[self._current_index, 'reward'])
        done = bool(self.df_trans.loc[self._current_index, 'done'])

        # Avanzar índice
        self._current_index = min(self._current_index + 1, self._max_index)

        # Obtener próximo estado
        row = self.df_state.loc[[self._current_index], self._raw_cols]
        next_state = self.pipeline.transform(row).astype(np.float32).flatten()
        return next_state, reward, done

    def render(self):
        """Muestra fila actual con reward."""
        info = self.df_state.loc[self._current_index, self._raw_cols].to_dict()
        info['reward'] = self.df_trans.loc[self._current_index, 'reward']
        print(info)
